$(document).ready(function() {
  $('#submit').click(function() {
     $("h3").toggleClass("h3after")
      $("div").toggleClass("container1")
  })
});