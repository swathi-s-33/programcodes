$(function(){
            $('#search-btn').click(function(){
               var str=$('#search').val();
                var spl=str.split(",");
               alert(spl);
               
            });
         });