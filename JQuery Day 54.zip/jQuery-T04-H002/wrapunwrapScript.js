$(function(){
    var i=1;
    $("#button1").click(function(){
        if(i%2!=0){
            $("p").wrap("<div></div>");
            i=i+1
        }
        else{
            $("p").unwrap();
            i=i+1
        } 
    
      });
})