$(function(){
    $("#div1").click(function(){
       $(this).css("background-color", "yellow")
    })
    $("#div2").click(function(){
        $(this).css("background-color", "green")
     })
     $("#div3").click(function(){
        $(this).css("background-color", "red")
     })
     $("#div4").click(function(){
        $(this).css("background-color", "pink")
     })

     var i=1
     $("#button1").click(function(){
         if(i=1){
            $("div").toggle();
         }
        
        
     })
})