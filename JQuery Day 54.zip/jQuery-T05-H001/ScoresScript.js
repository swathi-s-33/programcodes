$(function(){
    $("#total").text("0")
    $(".n1").change(function () {
        var marks=0;
        $(".n1").each(function(){
            if( $(this).val() != '' ){
                var inputval=$(this).val();
                marks=marks+parseInt(inputval)  
            }
           
        })
        $("#total").text(marks.toFixed(2))
   
    })

})