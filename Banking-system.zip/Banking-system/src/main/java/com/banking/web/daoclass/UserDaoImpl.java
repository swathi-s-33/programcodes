package com.banking.web.daoclass;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.banking.web.model.Customer;
import com.banking.web.model.Transaction;

@Repository
public class UserDaoImpl implements UserDao {
	 @Autowired
	  DataSource datasource;
	  @Autowired
	  JdbcTemplate jdbcTemplate;
	  private String name;
	@Override
	public List<Customer> retrievelistcustomers(Customer customer) {
		 String sql = "select * from customers";
		 List <Customer> users = jdbcTemplate.query(sql, 
		         new ResultSetExtractor<List<Customer>>() {
			 public List<Customer> extractData(
			            ResultSet rs) throws SQLException, DataAccessException {
				 List<Customer> list = new ArrayList<Customer>();  
				 while(rs.next()){ 
					  Customer customer=new Customer();
					  customer.setCust_id(rs.getString("cust_id"));
					  customer.setFirstname(rs.getString("firstname"));
					  customer.setEmail(rs.getString("email"));
					  customer.setCurrent_balance(rs.getString("current_balance"));
					  list.add(customer);
				 }
				  return list;
			 }    	  
	      });
		 	
		 return users;
	}
	@Override
	public List<Transaction> returntrans(Transaction trans) {
		trans.setTrans_id(UUID.randomUUID().toString());
		String sql = "insert into transaction_table values(?,?,?)";
		jdbcTemplate.update(sql, new Object[] {trans.getCust_id(),trans.getTrans_id(), trans.getAmount()});
		 String sqln = "select firstname from customers where cust_id='" + trans.getCust_id()+ "'";
		 List<Transaction> firstname = jdbcTemplate.query(sqln, new NameMapper());
		 
		 String sqlp = "select * from transaction_table where cust_id='" +trans.getCust_id() + "'";
		 List <Transaction> users = jdbcTemplate.query(sqlp, 
		         new ResultSetExtractor<List<Transaction>>() {
			 public List<Transaction> extractData(
			            ResultSet rs) throws SQLException, DataAccessException {
				 List<Transaction> list = new ArrayList<Transaction>();  
				 while(rs.next()){ 
					  Transaction trans=new Transaction();
					  trans.setCust_id(rs.getString("cust_id"));
					  trans.setTrans_id(rs.getString("trans_id"));
					  trans.setAmount(rs.getString("amount"));
					  trans.setReceipt_name(firstname.get(0).getReceipt_name());
					  list.add(trans);
				 }
				  return list;
			 }    	  
	      });
		 	return users;
	}
	 class NameMapper implements RowMapper<Transaction> {
		  public Transaction mapRow(ResultSet rs, int arg1) throws SQLException {
		    Transaction trans = new Transaction();
		    trans.setReceipt_name(rs.getString("firstname"));
		    return trans;
		  }
		  }
}
