package com.banking.web.model;

public class Customer {
	private String cust_id;
	private String firstname;
	private String email;
	private String current_balance;
	public String getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCurrent_balance() {
		return current_balance;
	}
	public void setCurrent_balance(String current_balance) {
		this.current_balance = current_balance;
	}
	@Override
	public String toString() {
		return String.format("Customer [cust_id=%s, firstname=%s, email=%s, current_balance=%s]", cust_id, firstname,
				email, current_balance);
	}
	
}
