package com.banking.web.model;

public class Transaction {
 private String cust_id;
 private String trans_id;
 private String amount;
 private String receipt_name;
public String getCust_id() {
	return cust_id;
}
public void setCust_id(String cust_id) {
	this.cust_id = cust_id;
}
public String getTrans_id() {
	return trans_id;
}
public void setTrans_id(String trans_id) {
	this.trans_id = trans_id;
}
public String getAmount() {
	return amount;
}
public void setAmount(String amount) {
	this.amount = amount;
}
@Override
public String toString() {
	return String.format("Transaction [cust_id=%s, trans_id=%s, amount=%s, receipt_name=%s]", cust_id, trans_id, amount,
			receipt_name);
}
public String getReceipt_name() {
	return receipt_name;
}
public void setReceipt_name(String receipt_name) {
	this.receipt_name = receipt_name;
}
}
