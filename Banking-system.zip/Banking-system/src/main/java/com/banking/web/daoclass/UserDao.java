package com.banking.web.daoclass;

import java.util.List;

import com.banking.web.model.Customer;
import com.banking.web.model.Transaction;

public interface UserDao {

	public abstract List<Customer> retrievelistcustomers(Customer customer);

	public abstract List<Transaction> returntrans(Transaction trans);

}
