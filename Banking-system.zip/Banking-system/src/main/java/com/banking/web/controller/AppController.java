package com.banking.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.banking.web.daoclass.UserDao;
import com.banking.web.model.Customer;
import com.banking.web.model.Transaction;

@Controller
public class AppController {
	@Autowired
	private UserDao userdao;
	private int id;
	@RequestMapping(value="/listcustomers",method=RequestMethod.GET)
	public ModelAndView loginMessage(ModelMap model){
		 ModelAndView mav = new ModelAndView("firstpage");
		 return mav;
	}
	@RequestMapping(value="/firstpage",method=RequestMethod.GET)
	public ModelAndView listcustomers(ModelMap model,Customer customer){
		List <Customer> value=userdao.retrievelistcustomers(customer);
		 ModelAndView mav = new ModelAndView("listcustomers");
		 mav.addObject("customers",value);
		 return mav;
	}
	@RequestMapping(value="/one-customer",method=RequestMethod.GET)
	public ModelAndView starttransaction(ModelMap model,Customer cust,@RequestParam String id){
		System.out.println(cust.getFirstname());
		 ModelAndView mav = new ModelAndView("one-customer");
		 id=cust.getCust_id();
		 mav.addObject("custom",new Transaction());
		 return mav;
	}
	@RequestMapping(value="/one-customer",method=RequestMethod.POST)
	public ModelAndView transaction(ModelMap model,Transaction trans){
		 ModelAndView mav = new ModelAndView("success");
		 List <Transaction> value=userdao.returntrans(trans);
		 mav.addObject("customers",value.get(0));
		 return mav;
	}
	@RequestMapping(value="/firstpage",method=RequestMethod.POST)
	public ModelAndView listcustomersreturn(ModelMap model){
		 ModelAndView mav = new ModelAndView("listcustomers");
		 return mav;
	}

}
