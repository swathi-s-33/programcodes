create database bankingsystem;
use bankingsystem;
create table customers(
cust_id int not null,
firstname VARCHAR(45) NOT NULL,
email varchar(45) null,
current_balance varchar(45) not null
);
create table transaction_table(
cust_id int not null,
trans_id int not null,
amount varchar(45) null
);
select*from customers;
select*from transaction_table;
insert into customers(cust_id,firstname,email,current_balance)
values('001','Swathi','sswathi0509@gmail.com','600.00');
insert into customers(cust_id,firstname,email,current_balance)
values('002','Selvi','selvithanasi@gmail.com','300.00');
insert into customers(cust_id,firstname,email,current_balance)
values('003','Naveena','naveenadhaks@gmail.com','800.00');
insert into customers(cust_id,firstname,email,current_balance)
values('004','Priya','jpriyadharshini@gmail.com','900.00');
insert into customers(cust_id,firstname,email,current_balance)
values('005','pavadharani','pavadharani@gmail.com','550.00');
insert into customers(cust_id,firstname,email,current_balance)
values('006','Vanathi','vans@gmail.com','980.00');
insert into customers(cust_id,firstname,email,current_balance)
values('007','Vinotha','vinorae@gmail.com','780.00');
insert into customers(cust_id,firstname,email,current_balance)
values('008','Sindhuja','sindhu@gmail.com','982.00');
insert into customers(cust_id,firstname,email,current_balance)
values('009','Sricharan','sricharan@gmail.com','690.00');
insert into customers(cust_id,firstname,email,current_balance)
values('010','dhina','dhina92@gmail.com','680.00');
