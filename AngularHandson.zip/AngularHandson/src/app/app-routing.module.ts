import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EditEmpReactiveComponent } from './edit-emp-reactive/edit-emp-reactive.component';

const routes: Routes = [
  {
    path:"edit-emp-reactive",
    component:EditEmpReactiveComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
