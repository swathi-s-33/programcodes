import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-edit-emp-reactive',
  templateUrl: './edit-emp-reactive.component.html',
  styleUrls: ['./edit-emp-reactive.component.css']
})
export class EditEmpReactiveComponent implements OnInit {
  Form: any;


  constructor( private formbuilder:FormBuilder) { }
//name:FormControl;
  ngOnInit(): void {
// this.name=new FormControl("John");
this.Form=this.formbuilder.group({
  'name':['John',[
    Validators.required,
    Validators.maxLength(20),
    Validators.minLength(4)
  ]],})
  }
  get name() { return this.Form.get('name'); }
}
