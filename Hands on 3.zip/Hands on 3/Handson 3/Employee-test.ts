import {Employee} from './Employee'

var e1:Employee={
    id:1001,
    name:"John",
    salary:10000,
    permanent:true
}

console.log(`ID:${e1.id}`);
console.log(`Name:${e1.name}`);
console.log(`Salary:${e1.salary}`);
console.log(`Permanent:${e1.permanent}`);

