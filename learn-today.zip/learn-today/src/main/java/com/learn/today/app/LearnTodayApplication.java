package com.learn.today.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnTodayApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnTodayApplication.class, args);
	}

}
