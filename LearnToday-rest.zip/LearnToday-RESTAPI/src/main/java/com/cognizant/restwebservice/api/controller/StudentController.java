package com.cognizant.restwebservice.api.controller;

public class StudentController {

}
