package com.cognizant.restwebservice.api.model;

public class Trainer {

}
