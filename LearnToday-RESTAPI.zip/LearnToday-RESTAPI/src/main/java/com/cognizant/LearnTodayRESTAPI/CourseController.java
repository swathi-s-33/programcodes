package com.cognizant.LearnTodayRESTAPI;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.LearnTodayRESTAPI.DAO.Course;
import com.cognizant.LearnTodayRESTAPI.service.CourseService;

@RestController
@RequestMapping("/api")
public class CourseController {
	
	@Autowired
	private CourseService courseservice;
	
	@GetMapping(path = "/Admin", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<Course>> getAllCourses() {
		List<Course> list = (List<Course>) courseservice.findAll();
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@GetMapping(value = "/Admin/{id}", produces = { "application/json", "application/xml"})
	public ResponseEntity<Optional<Course>> getAllCoursesById(@PathVariable String id) {
		Optional<Course> list = courseservice.findById(Integer.parseInt(id));
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
}
