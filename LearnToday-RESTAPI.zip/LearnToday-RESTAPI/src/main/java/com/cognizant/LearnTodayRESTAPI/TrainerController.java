package com.cognizant.LearnTodayRESTAPI;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.LearnTodayRESTAPI.DAO.Trainer;
import com.cognizant.LearnTodayRESTAPI.service.TrainerService;

@RestController
@RequestMapping("/api")
public class TrainerController {

		@Autowired
		private TrainerService trainerservice;
		
		@PostMapping(path = "/Trainer", consumes = { "application/xml", "application/json" })
		public ResponseEntity<String> trainerSignUp(@RequestBody Trainer trainer) {
			trainerservice.save(trainer);
			return new ResponseEntity<String>("Trainer Informations are created Successfully", HttpStatus.CREATED);
		}
		
		@PutMapping(path = "/Trainer/{id}", consumes = { "application/xml", "application/json" })
		public ResponseEntity<String> trainerPassword(@RequestBody Trainer trainer, @PathVariable String id) {
			Optional<Trainer> list = trainerservice.findById(Integer.parseInt(id));
			Trainer old = list.get();
			old.setPassword(trainer.getPassword());
			trainerservice.save(old);
			return new ResponseEntity<String>("Trainer Informations are cahnged Successfully", HttpStatus.CREATED);
		}
}
