package com.cognizant.LearnTodayRESTAPI.DAO;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student {

	@Id
	@Column(name="EnrollmentId")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int enrollmentid;
	@Column(name="StudentId")
	private int studentid;
	@Column(name="CourseId")
	private int courseid;
	public int getEnrollmentid() {
		return enrollmentid;
	}
	public void setEnrollmentid(int enrollmentid) {
		this.enrollmentid = enrollmentid;
	}
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public int getCourseid() {
		return courseid;
	}
	public void setCourseid(int courseid) {
		this.courseid = courseid;
	}
}
