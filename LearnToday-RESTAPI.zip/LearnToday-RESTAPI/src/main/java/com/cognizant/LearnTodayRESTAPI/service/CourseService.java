package com.cognizant.LearnTodayRESTAPI.service;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.LearnTodayRESTAPI.DAO.Course;

public interface CourseService extends CrudRepository<Course, Integer>{

}
