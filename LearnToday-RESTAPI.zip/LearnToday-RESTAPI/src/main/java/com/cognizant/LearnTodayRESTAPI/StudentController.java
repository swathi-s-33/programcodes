package com.cognizant.LearnTodayRESTAPI;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cognizant.LearnTodayRESTAPI.DAO.Student;
import com.cognizant.LearnTodayRESTAPI.service.StudentService;

@RestController
@RequestMapping("/api")
public class StudentController {

	@Autowired
	private StudentService studentservice;

	@GetMapping(path = "/Students", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<Student>> getAllStudents() {
		List<Student> list = (List<Student>) studentservice.findAll();
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@PostMapping(path = "/Students", consumes = { "application/xml", "application/json" })
	public ResponseEntity<String> addCustomer(@RequestBody Student student) {
		studentservice.save(student);
		return new ResponseEntity<String>("Student Informations are saved Successfully", HttpStatus.CREATED);
	}
	
	@DeleteMapping(value = "/Students/{id}")
	public ResponseEntity<String> getAllCoursesById(@PathVariable String id) {
		studentservice.deleteById(Integer.parseInt(id));
		return new ResponseEntity<String>("Student Informations are deleted Successfully", HttpStatus.OK);
	}
}
