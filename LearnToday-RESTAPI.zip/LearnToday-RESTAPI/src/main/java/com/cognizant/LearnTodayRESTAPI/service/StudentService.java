package com.cognizant.LearnTodayRESTAPI.service;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.cognizant.LearnTodayRESTAPI.DAO.Student;

@Service
public interface StudentService extends CrudRepository<Student, Integer>{

}
