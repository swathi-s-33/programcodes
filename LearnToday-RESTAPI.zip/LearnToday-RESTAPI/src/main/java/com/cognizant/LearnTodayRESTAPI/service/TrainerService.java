package com.cognizant.LearnTodayRESTAPI.service;

import org.springframework.data.repository.CrudRepository;
import com.cognizant.LearnTodayRESTAPI.DAO.Trainer;

public interface TrainerService extends CrudRepository<Trainer, Integer>{

}
