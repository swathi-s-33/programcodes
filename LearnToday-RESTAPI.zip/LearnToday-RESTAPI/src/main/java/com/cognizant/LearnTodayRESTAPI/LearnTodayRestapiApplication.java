package com.cognizant.LearnTodayRESTAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnTodayRestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnTodayRestapiApplication.class, args);
	}

}
