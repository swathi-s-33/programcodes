package com.cognizant.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.Course;
import com.cognizant.repository.Courserepo;

@Service
@Transactional
public class CourseService {

	private Courserepo courserepo;
	
	public CourseService(Courserepo courserepo) {
		this.courserepo = courserepo;
	}

	public List<Course> getallCourse()
	{
		System.out.println("all course");
		List<Course> courselist=new ArrayList<Course>();
		for (Course course : courserepo.findAll()) {
			System.out.println(course);
			courselist.add(course);
		}
		return courselist;
	}
	
	public Optional<Course> getbyId(int id)
	{
		Optional<Course> courseobj=Optional.ofNullable(new Course());
		courseobj= courserepo.findById(id);
		return courseobj;
	}
	
	
}
