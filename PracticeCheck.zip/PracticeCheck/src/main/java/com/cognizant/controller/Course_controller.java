package com.cognizant.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Course;
import com.cognizant.repository.Courserepo;
import com.cognizant.service.CourseService;

@RestController
public class Course_controller {
	

	@Autowired
	CourseService cservice;
	
	@GetMapping("/allcourse")
	public List<Course> allcourse()
	{
		//Course cou=(Course) cservice.getallCourse();
		List<Course> courselist=cservice.getallCourse();
		return courselist;
	}
	@GetMapping("/course/{courseid}")
	public Optional<Course> fbyid(@PathVariable int courseid)
	{
		Optional<Course> course= Optional.ofNullable(new Course());
		course= cservice.getbyId(courseid);
		return course;
	}
}
