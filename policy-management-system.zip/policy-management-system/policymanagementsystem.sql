create database policyholders;
use policyholders;
create table registerusers(
firstname VARCHAR(45) NOT NULL,
lastname varchar(45) null,
username varchar(45) not null,
gender varchar(45) null,
dob varchar(45) null,
password varchar(45) null
);
select*from registerusers;
