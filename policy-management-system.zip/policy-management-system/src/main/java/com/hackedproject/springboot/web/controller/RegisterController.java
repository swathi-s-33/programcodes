package com.hackedproject.springboot.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hackedproject.springboot.web.daoclass.UserDao;
import com.hackedproject.springboot.web.model.Login;
import com.hackedproject.springboot.web.model.User;
import com.hackedproject.springboot.web.serviceclass.UserService;

@Controller
public class RegisterController {

	@Autowired
	UserService userService;
	@Autowired
	UserDao UserDao;
	@RequestMapping(value="/new-registration",method=RequestMethod.GET)
	public ModelAndView ShowRegistrayionPage(ModelMap model){
		ModelAndView mav = new ModelAndView("new-registration");
		 mav.addObject("user", new User());
		return mav;
	}
	@RequestMapping(value="/new-registration",method=RequestMethod.POST)
	public ModelAndView ShowLoginPage(ModelMap model,@RequestParam String firstname,@ModelAttribute("user") User user){
		//model.put("firstname",firstname);
		boolean value= userService.register(user);
		ModelAndView mav=null;
	//	System.out.println("Name is"+name);
		if(value==true)
		{
		 mav=new ModelAndView("thankyou", "firstname", user.getFirstname());
		}
		else
		{
			 mav = new ModelAndView("new-registration");
		   	    mav.addObject("message", "You are Already registered!!");
		}
		return mav;
	}
	@RequestMapping(value="/forgetpassword",method=RequestMethod.GET)
	public ModelAndView ShowPasswordResetPage(ModelMap model){
		ModelAndView mav = new ModelAndView("forgetpassword");
		// mav.addObject("user", new User());
		return mav;
	}
	@RequestMapping(value="/forgetpassword",method=RequestMethod.POST)
	public ModelAndView ShowAgainLoginPage(ModelMap model,@ModelAttribute("login") Login login){
		userService.changepassword(login);
		ModelAndView mav = new ModelAndView("redirect:/login");
		// mav.addObject("user", new User());
		return mav;
	}
}
