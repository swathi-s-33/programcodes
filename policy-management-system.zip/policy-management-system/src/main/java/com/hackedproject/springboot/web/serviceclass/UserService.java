package com.hackedproject.springboot.web.serviceclass;

import org.springframework.stereotype.Service;

import com.hackedproject.springboot.web.model.AddPolicy;
import com.hackedproject.springboot.web.model.Login;
import com.hackedproject.springboot.web.model.Policy;
import com.hackedproject.springboot.web.model.UpdatePolicy;
import com.hackedproject.springboot.web.model.User;

import java.util.List;

import org.springframework.context.annotation.Bean;
@Service
public interface UserService {
	public abstract boolean register(User user);
	public abstract User validateUser(Login login);
	public abstract List <Policy>  retrievePolicies(Policy policy);
	public abstract List <AddPolicy> addpolicy(Policy policies);
	public abstract List <UpdatePolicy> retrivepolicy(Policy upolicy,String id);
	public abstract void updatepolicy(UpdatePolicy upolicies);
	public abstract void changepassword(Login login);
}
