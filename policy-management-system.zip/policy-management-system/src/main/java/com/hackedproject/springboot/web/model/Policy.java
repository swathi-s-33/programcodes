package com.hackedproject.springboot.web.model;

public class Policy {
	private String username;
	private String policyid;
	private String policyname;
	private String policynumber;
	private String installmentpremium;
	private String sumassured;
	private String noofyears;
	private String survivalbenefits;
	private String deathbenefits;
	private String policystatus;

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPolicyname() {
		return policyname;
	}
	public void setPolicyname(String policyname) {
		this.policyname = policyname;
	}
	public String getPolicynumber() {
		return policynumber;
	}
	public void setPolicynumber(String policynumber) {
		this.policynumber = policynumber;
	}
	public String getInstallmentpremium() {
		return installmentpremium;
	}
	public void setInstallmentpremium(String installmentpremium) {
		this.installmentpremium = installmentpremium;
	}
	public String getSumassured() {
		return sumassured;
	}
	public void setSumassured(String sumassured) {
		this.sumassured = sumassured;
	}
	public String getNoofyears() {
		return noofyears;
	}
	public void setNoofyears(String noofyears) {
		this.noofyears = noofyears;
	}
	
	public String getSurvivalbenefits() {
		return survivalbenefits;
	}
	public void setSurvivalbenefits(String survivalbenefits) {
		this.survivalbenefits = survivalbenefits;
	}
	public String getDeathbenefits() {
		return deathbenefits;
	}
	public void setDeathbenefits(String deathbenefits) {
		this.deathbenefits = deathbenefits;
	}
	public String getPolicystatus() {
		return policystatus;
	}
	public void setPolicystatus(String policystatus) {
		this.policystatus = policystatus;
	}
	public String getPolicyid() {
		return policyid;
	}
	public void setPolicyid(String policyid) {
		this.policyid = policyid;
	}
	 private String nameofbank;
	 private String ifsccode;
	 private String accountnumber;
	 private String nominee;
	public String getNameofbank() {
		return nameofbank;
	}
	public void setNameofbank(String nameofbank) {
		this.nameofbank = nameofbank;
	}
	public String getIfsccode() {
		return ifsccode;
	}
	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}
	public String getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}
	public String getNominee() {
		return nominee;
	}
	public void setNominee(String nominee) {
		this.nominee = nominee;
	}
	@Override
	public String toString() {
		return String.format(
				"Policy [username=%s, policyid=%s, policyname=%s, policynumber=%s, installmentpremium=%s, sumassured=%s, noofyears=%s, survivalbenefits=%s, deathbenefits=%s, policystatus=%s, nameofbank=%s, ifsccode=%s, accountnumber=%s, nominee=%s]",
				username, policyid, policyname, policynumber, installmentpremium, sumassured, noofyears,
				survivalbenefits, deathbenefits, policystatus, nameofbank, ifsccode, accountnumber, nominee);
	}
	
}
