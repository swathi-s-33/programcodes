package com.hackedproject.springboot.web.model;

public class UpdatePolicy {
 private String username;
 private String policyid;
 private String nameofbank;
 private String ifsccode;
 private String accountnumber;
 private String nominee;
public String getPolicyid() {
	return policyid;
}
public void setPolicyid(String policyid) {
	this.policyid = policyid;
}
public String getNameofbank() {
	return nameofbank;
}
public void setNameofbank(String nameofbank) {
	this.nameofbank = nameofbank;
}
public String getIfsccode() {
	return ifsccode;
}
public void setIfsccode(String ifsccode) {
	this.ifsccode = ifsccode;
}
public String getAccountnumber() {
	return accountnumber;
}
public void setAccountnumber(String accountnumber) {
	this.accountnumber = accountnumber;
}
public String getNominee() {
	return nominee;
}
public void setNominee(String nominee) {
	this.nominee = nominee;
}

public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
@Override
public String toString() {
	return String.format(
			"UpdatePolicy [username=%s, policyid=%s, nameofbank=%s, ifsccode=%s, accountnumber=%s, nominee=%s]",
			username, policyid, nameofbank, ifsccode, accountnumber, nominee);
}

}
