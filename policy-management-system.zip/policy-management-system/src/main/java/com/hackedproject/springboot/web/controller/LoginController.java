package com.hackedproject.springboot.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hackedproject.springboot.web.model.AddPolicy;
import com.hackedproject.springboot.web.model.Login;
import com.hackedproject.springboot.web.model.Policy;
import com.hackedproject.springboot.web.model.UpdatePolicy;
import com.hackedproject.springboot.web.model.User;
import com.hackedproject.springboot.web.serviceclass.UserService;
@Controller 
public class LoginController {
	 @Autowired
	  UserService userService;
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public ModelAndView loginMessage(ModelMap model){
	//	model.put("name",name);
	//	System.out.println("Name is"+name);
		 ModelAndView mav = new ModelAndView("login");
		    mav.addObject("login", new Login());
		    return mav;
	}
	@RequestMapping(value="/login", method = RequestMethod.POST)
	public ModelAndView showWelcomePage(@RequestParam String username, @RequestParam String password,ModelMap model,@ModelAttribute("login") Login login){
   		model.put("username",username);
   		model.put("password",password);
   		ModelAndView mav = new ModelAndView("mainpage");  
   	    User user = userService.validateUser(login);
   	    String var=login.getUsername();
   	    if (null != user) {
   	    mav = new ModelAndView("mainpage");
   	    mav.addObject("firstname", user.getFirstname());
   	    mav.addObject("username",var);
   	    } else {
   	    mav = new ModelAndView("login");
   	    mav.addObject("message", "Username or Password is wrong!!");
   	    }
   	    return mav;
	}
	@RequestMapping(value="/list-policies", method = RequestMethod.GET)
	public ModelAndView showPolicies(ModelMap model,Policy policy){
		//String name = (String) model.get("username");
		//System.out.println(login.getUsername());
		List <Policy> value=userService.retrievePolicies(policy);
		ModelAndView mav =new ModelAndView("list-policies");
	//	System.out.println(value);
		mav.addObject("policies",value);
		return mav;
	}
	@RequestMapping(value = "/add-policies", method = RequestMethod.GET)
	public ModelAndView showAddPolicyPage(ModelMap model) {
		 ModelAndView mav = new ModelAndView("policy");
		model.addAttribute("policy", new Policy());
		return mav;
	}
	@RequestMapping(value = "/add-policies", method = RequestMethod.POST)
	public  ModelAndView ReturnListPolicies(ModelMap model,@ModelAttribute("policy") Policy policies,BindingResult result) {
		List <AddPolicy> values=userService.addpolicy(policies);
		ModelAndView mav = new ModelAndView("redirect:/list-policies");
		return mav ;
	}
	@RequestMapping(value = "/update-policies", method = RequestMethod.GET)
	public ModelAndView ShowUpdatePolicyPage(ModelMap model,Policy upolicy,@RequestParam String id) {
		List <UpdatePolicy> value = userService.retrivepolicy(upolicy,id);
		ModelAndView mav = new ModelAndView("policy");
		UpdatePolicy policy=value.get(0);
		mav.addObject("policy",policy);
		return mav;
	}

	@RequestMapping(value = "/update-policies", method = RequestMethod.POST)
	public ModelAndView ShowUpdatedListPage(ModelMap model, @ModelAttribute("policy") UpdatePolicy upolicies,
			BindingResult result) {
		ModelAndView mav = new ModelAndView("redirect:/list-policies");
		userService.updatepolicy(upolicies);
		return mav;
	}
	@RequestMapping(value="/show-policies",method=RequestMethod.GET)
	public ModelAndView ShowPolicies(ModelMap model){
		ModelAndView mav = new ModelAndView("showpolicies");
		return mav;
	}
	@RequestMapping(value="/show-policies",method=RequestMethod.POST)
	public ModelAndView ReturnTOPolicies(ModelMap model){
		ModelAndView mav = new ModelAndView("redirect:/list-policies");
		return mav;
	}
}
