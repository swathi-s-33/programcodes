package com.hackedproject.springboot.web.daoclass;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.hackedproject.springboot.web.model.AddPolicy;
import com.hackedproject.springboot.web.model.Login;
import com.hackedproject.springboot.web.model.Policy;
import com.hackedproject.springboot.web.model.UpdatePolicy;
import com.hackedproject.springboot.web.model.User;
@Service
public class UserDaoImpl implements UserDao{

	  @Autowired
	  DataSource datasource;
	  @Autowired
	  JdbcTemplate jdbcTemplate;
	  public String name;
	  public String pid;
	  
	  @Override
	  public Boolean register(User user) {
		 String sqlr = "select  username from registerusers where username='" + user.getUsername() +"'";
		// System.out.println(sqlr);	
		 List<User> users = jdbcTemplate.query(sqlr, new RegisterMapper());
		// System.out.println(users.size());
		 if( users.size()==0)
		 {
			String sql = "insert into registerusers values(?,?,?,?,?,?,?)";
			jdbcTemplate.update(sql, new Object[] { user.getFirstname(), user.getLastname(), user.getUsername(),
					user.getGender(), user.getDob(), user.getPannumber(),user.getPassword()});
		//	System.out.println("true");
			return true;
		 }
		 else {
			 return false;
		 }
		 
	  }
	  	@Override 
	    public User validateUser(Login login) {
	    String sql = "select * from registerusers where username='" + login.getUsername() + "' and password='" + login.getPassword()
	    + "'";
	  //  System.out.println(sql);
	    List<User> users = jdbcTemplate.query(sql, new UserMapper());
	    	for (User user:users)
	    	{
	    		name=user.getUsername();
	    	}
	    //	System.out.println(name);
	    	return users.size() > 0 ? users.get(0) : null;
	    }
	  @Override
		public List <Policy> retrievePolicies(Policy policy) {
				 String sql = "select * from policydetails where username='" + name + "'";
				 List <Policy> users = jdbcTemplate.query(sql, 
				         new ResultSetExtractor<List<Policy>>() {
					 public List<Policy> extractData(
					            ResultSet rs) throws SQLException, DataAccessException {
						 List<Policy> list = new ArrayList<Policy>();  
						 while(rs.next()){ 
							  Policy policy=new Policy();
							  policy.setUsername(rs.getString("username"));
							  policy.setPolicyid(rs.getString("policy_id"));
							//  System.out.println(rs.getString("policy_id"));
							  policy.setPolicyname(rs.getString("policyname"));
							  policy.setPolicynumber(rs.getString("policynumber"));
							  policy. setInstallmentpremium(rs.getString("installmentpremium"));
							  policy.setSumassured(rs.getString("sumassured"));
							  policy.setNoofyears(rs.getString("noofyears"));
							  policy.setSurvivalbenefits(rs.getString("survivalbenefits"));
							  policy.setDeathbenefits(rs.getString("deathbenefits"));
							  policy.setPolicystatus(rs.getString("policystatus"));
							  list.add(policy);
						 }
						  return list;
					 }    	  
			      });
				// System.out.println(users);
				 	return users;
	  }
				 /*   List<Policy> users = jdbcTemplate.query(sql, new PolicyMapper  ());
				  //  System.out.println(login.getUsername());
				    System.out.println(users.size());
				    return users.size() > 0 ? users.get(0) : null;
				    }*/
	@Override
	public List <AddPolicy> addpolicy(Policy policies) {
		 String sqls = "select * from allpolicies where policy_id='" +policies.getPolicyid() + "'";
		// System.out.println(policies.getPolicyid());
		// System.out.println(sqls);
		 List <AddPolicy> users = jdbcTemplate.query(sqls, 
		         new ResultSetExtractor<List<AddPolicy>>() {
			 public List<AddPolicy> extractData(
			            ResultSet rs) throws SQLException, DataAccessException {
				 List<AddPolicy> list = new ArrayList<AddPolicy>();  
				 while(rs.next()){ 
					  AddPolicy policy=new AddPolicy();
					  policy.setPolicyid(rs.getString("policy_id"));
					  policy.setPolicyname(rs.getString("policyname"));
					  policy.setPolicynumber(rs.getString("policynumber"));
					  policy. setInstallmentpremium(rs.getString("installmentpremium"));
					  policy.setSumassured(rs.getString("sumassured"));
					  policy.setNoofyears(rs.getString("noofyears"));
					  policy.setSurvivalbenefits(rs.getString("survivalbenefits"));
					  policy.setDeathbenefits(rs.getString("deathbenefits"));
					  policy.setPolicystatus(rs.getString("policystatus"));
					  list.add(policy);
				 }
				  return list;
			 }    	  
	      });
		 String sqlp = "insert into policydetails values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		 for(AddPolicy p:users)
		 {
			 jdbcTemplate.update(sqlp, new Object[] {name, p.getPolicyid(),p.getPolicyname(), p. getPolicynumber(),
					    p.getInstallmentpremium(), p.getSumassured() , p.getNoofyears(),p.getSurvivalbenefits(),p.getDeathbenefits(),p.getPolicystatus(),policies.getNameofbank(),policies.getIfsccode(),policies.getAccountnumber(),policies.getNominee()}); 
		 }
		//   System.out.println(users);
		 	return users;
		 }
	@Override
	public List<UpdatePolicy> retrivepolicy(Policy upolicy,String id) {
		String sqlu = "select policy_id,nameofbank,ifsccode,accountnumber,nominee from policydetails where policy_id='"+id+ "' and username='" +name + "'";
		pid=id;
		 	System.out.println(upolicy.getPolicyid());
		//System.out.println(id);
		//System.out.println(sqlu);
		List <UpdatePolicy> users = jdbcTemplate.query(sqlu,new ResultSetExtractor<List<UpdatePolicy>>() {
			 public List<UpdatePolicy> extractData(  ResultSet rs) throws SQLException, DataAccessException {
				 List<UpdatePolicy> list = new ArrayList<UpdatePolicy>();  
				 while(rs.next()){ 
					  UpdatePolicy policy=new UpdatePolicy();
					  policy.setPolicyid(rs.getString("policy_id"));
					//  System.out.println(rs.getString("policy_id"));
					  policy.setNameofbank(rs.getString("nameofbank"));
					  policy.setIfsccode(rs.getString("ifsccode"));
					  policy.setAccountnumber(rs.getString("accountnumber"));
					  policy.setNominee(rs.getString("nominee"));
					  list.add(policy);
				 }
				  return list;
			 }    	  
	      });
		// System.out.println(users);
		 	return users;
	}
	@Override
	public void updatepolicy(UpdatePolicy upolicies) {
		 String sqlup = "update policydetails set nameofbank='"+upolicies.getNameofbank()+"',"+ "ifsccode='"+upolicies.getIfsccode()+"'," + "accountnumber='"+upolicies.getAccountnumber()+"',"+"nominee='"+upolicies.getNominee()+"'"+ "where policy_id='"+pid+"'and username='" +name+ "'";
		// System.out.println(upolicies.getPolicyid());
		// System.out.println(sqlup);
		 jdbcTemplate.update(sqlup);
				/* { upolicies.getNameofbank(), upolicies.getIfsccode(), upolicies.getIfsccode(),
				    upolicies.getAccountnumber(), upolicies.getNominee()});*/
		 
	}
	@Override
	public void changepassword(Login login) {
		String sqlpass="update registerusers set password='"+login.getPassword()+"'"+"where username='"+login.getUsername()+"'";
		jdbcTemplate.update(sqlpass);
	}
	
}	 
	  
	  class UserMapper implements RowMapper<User> {
	  public User mapRow(ResultSet rs, int arg1) throws SQLException {
	    User user = new User();
	    user.setFirstname(rs.getString("firstname"));
	    user.setLastname(rs.getString("lastname"));
	    user.setUsername(rs.getString("username"));
	    user.setGender(rs.getString("gender"));
	    user.setDob(rs.getString("dob"));
	    user.setPannumber(rs.getString("pannumber"));
	    user.setPassword(rs.getString("password"));
	    return user;
	  }
	  }
        class RegisterMapper implements RowMapper<User> {
			  public User mapRow(ResultSet rs, int arg1) throws SQLException {
			    User user = new User();
			    user.setUsername(rs.getString("username"));
			   // System.out.println(policy.getInstallmentpremium());
			    return user;
			  }
          }
	
	 

