package com.hackedproject.springboot.web.serviceclass;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hackedproject.springboot.web.daoclass.UserDao;
import com.hackedproject.springboot.web.model.AddPolicy;
import com.hackedproject.springboot.web.model.Login;
import com.hackedproject.springboot.web.model.Policy;
import com.hackedproject.springboot.web.model.UpdatePolicy;
import com.hackedproject.springboot.web.model.User;
@Service
public class UserServiceImpl implements UserService{
	@Autowired
	UserDao UserDao;
	@Override
	public boolean register(User user)
	{
		return UserDao.register(user);
	}
	@Override
	public User validateUser(Login login)
	{
		return UserDao.validateUser(login);
	}
	@Override
	public List <Policy> retrievePolicies( Policy policy) {
	  return	UserDao.retrievePolicies(policy);
		
	}
	@Override
	public List <AddPolicy> addpolicy(Policy policies) {
		return UserDao.addpolicy(policies);
		
	}
	@Override
	public List<UpdatePolicy> retrivepolicy(Policy upolicy,String id) {
		return UserDao.retrivepolicy(upolicy,id);
	}
	@Override
	public void updatepolicy(UpdatePolicy upolicies) {
		UserDao.updatepolicy(upolicies);
		
	}
	@Override
	public void changepassword(Login login) {
		UserDao.changepassword(login);
	}

}
