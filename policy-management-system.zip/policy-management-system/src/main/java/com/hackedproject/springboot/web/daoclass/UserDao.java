package com.hackedproject.springboot.web.daoclass;

import java.util.List;

import com.hackedproject.springboot.web.model.AddPolicy;
import com.hackedproject.springboot.web.model.Login;
import com.hackedproject.springboot.web.model.Policy;
import com.hackedproject.springboot.web.model.UpdatePolicy;
import com.hackedproject.springboot.web.model.User;

public interface UserDao {
	public abstract Boolean register(User user);
	public abstract User validateUser(Login login);
	public  abstract List <Policy> retrievePolicies(Policy policy);
	public abstract List <AddPolicy> addpolicy(Policy policies);
	public abstract List <UpdatePolicy> retrivepolicy(Policy upolicy,String id);
	public abstract void updatepolicy(UpdatePolicy upolicies);
	public abstract void changepassword(Login login);
	
}
