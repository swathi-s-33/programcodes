package com.hackedproject.springboot.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;



@SpringBootApplication
@ComponentScan("com.hackedproject.springboot.web")
public class PolicyManagementSystem {

	public static void main(String[] args) {
		SpringApplication.run(PolicyManagementSystem.class, args);
	}

}
