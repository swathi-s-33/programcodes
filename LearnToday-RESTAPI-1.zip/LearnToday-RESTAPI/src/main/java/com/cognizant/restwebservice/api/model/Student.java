package com.cognizant.restwebservice.api.model;

public class Student {
	private int EnrollmentId;
	private int StudentId;
	private int CourseId;
	public int getEnrollmentId() {
		return EnrollmentId;
	}
	public void setEnrollmentId(int enrollmentId) {
		EnrollmentId = enrollmentId;
	}
	public int getStudentId() {
		return StudentId;
	}
	public void setStudentId(int studentId) {
		StudentId = studentId;
	}
	public int getCourseId() {
		return CourseId;
	}
	public void setCourseId(int courseId) {
		CourseId = courseId;
	}
	@Override
	public String toString() {
		return "Student [EnrollmentId=" + EnrollmentId + ", StudentId=" + StudentId + ", CourseId=" + CourseId + "]";
	}
	
}
