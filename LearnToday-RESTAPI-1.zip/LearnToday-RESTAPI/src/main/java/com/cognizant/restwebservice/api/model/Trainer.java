package com.cognizant.restwebservice.api.model;

public class Trainer {
	private int TrainerId;
	private String varchar;
	public int getTrainerId() {
		return TrainerId;
	}
	public void setTrainerId(int trainerId) {
		TrainerId = trainerId;
	}
	public String getVarchar() {
		return varchar;
	}
	public void setVarchar(String varchar) {
		this.varchar = varchar;
	}
	@Override
	public String toString() {
		return "Trainer [TrainerId=" + TrainerId + ", varchar=" + varchar + "]";
	}

}
