package com.cognizant.restwebservice.api.service;

public class StudentService {

}
